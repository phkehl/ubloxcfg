The ProggyClean.ttf contains the Latin-1 character set (ISO 8859-1 I think)
The ProggyCleanCE.ttf can be used for the Czech language, but I assume it's just
Latin-2, so you can try it if the caracters you want are missing... and you can read
English enough to understand this readme :)
