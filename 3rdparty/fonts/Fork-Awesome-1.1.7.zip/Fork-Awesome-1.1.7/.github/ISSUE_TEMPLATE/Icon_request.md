---
name: Icon request
about: Suggest an icon for this project

---

<!-- Please review open and closed issues that the icon hasn't been requested before. -->

## Icon

<!--
      Please add an image for this icon
      As a general rule, images with simple shapes and only one color are the best.
      If this icon is a "brand" icon, let us know why this brand is important and what they do.
-->



## Name Suggestion

<!-- What name should be used for this icon? -->



## Use Case

<!-- Describe how a user of fork-awesome would use that icon in their project. -->


